***Note of the author***

"Joyride" is 100% free font!  
 Enjoy!